package Hogwarts;

/**
 * This is a game where you can explore around the Hogwarts castle of the Harry Potter world a bit.
 *
 * I planned on adding items you can get and random rooms to get teleported to but, It is beyond my current
 * level of comprehension of Java and time constraints.
 *
 * @version 1.04
 *
 */


public class Game {

    private Parser parser;
    private Room currentRoom;

    public Game()
    {
        createRooms();
        parser = new Parser();
    }
    public static void main(String[] args) {
        Game game = new Game();
        game.play();
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
        Room outside, commons, greatHall, dumbledore, dungeon;

        // create the rooms
        outside = new Room("outside the main entrance of the school");
        commons = new Room("in a common room");
        greatHall = new Room("at the great hall!");
        dumbledore = new Room("at Dumbledore's office");
        dungeon = new Room("at the potions dungeon");

        // initialise room exits
        outside.setExits("east", commons);
        outside.setExits("south", dumbledore);
        outside.setExits("west", greatHall);

        commons.setExits("west", outside);

        greatHall.setExits("east", outside);

        dumbledore.setExits("north", outside);
        dumbledore.setExits("east", dungeon);

        dungeon.setExits("west", dumbledore);

        currentRoom = outside;
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play()
    {
        printWelcome();

        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
        }
        System.out.println("Thank you for exploring Hogwarts. Good bye.");
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to the Hogwarts castle!");
        System.out.println("Here you can explore around a little bit...");
        System.out.println("Type 'help' if you need help.");
        printHelp();
        System.out.println();
        System.out.println(currentRoom.getLongDescription());
    }

    /**
     * Process the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    private boolean processCommand(Command command)
    {
        boolean wantToQuit = false;

        if(command.isUnknown()) {
            System.out.println("That isn't one of the available commands...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equals("help")) {
            printHelp();
        }
        else if (commandWord.equals("go")) {
            goRoom(command);
        }
        else if (commandWord.equals("look")) {
            look();
        }
        else if (commandWord.equals("rest")) {
            rest();
        }
        else if (commandWord.equals("quit")) {
            wantToQuit = quit(command);
        }

        return wantToQuit;
    }


    /**
     *
     * Print out the help information.
     *
     */
    private void printHelp()
    {
        System.out.println("You're wandering..");
        System.out.println();
        System.out.println("Your command words are:");
        String commandString = parser.showCommands();
        System.out.println(commandString);
    }

    /**
     * Try to go in one direction. If there is an exit, enter
     * the new room, otherwise print an error message.
     */
    private void goRoom(Command command)
    {
        if(!command.hasSecondWord()) {
            System.out.println("Go where?");
            return;
        }

        String direction = command.getSecondWord();


        Room nextRoom = currentRoom.getExit(direction);

        if (nextRoom == null) {
            System.out.println("There is no door!");
        }
        else {
            currentRoom = nextRoom;
            System.out.println(currentRoom.getLongDescription());
        }
    }

    /**
     * This gives you the option to type look to display
     * your current room and exits.
     *
     */
    private void look()
    {
        System.out.println(currentRoom.getLongDescription());
    }

    /**
     * Simulate resting if you get tired.
     */
    private void rest()
    {
        System.out.println("You are now resting...");
    }

    /**
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private boolean quit(Command command)
    {
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else {
            return true;
        }
    }
}
