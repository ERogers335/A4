package Hogwarts;

public class CommandWords {
    private static final String[] validCommands = {
            "go", "quit", "help", "look", "rest", "take"
    };

    /**
     * Constructor - initialise the command words.
     */
    public CommandWords()
    {

    }

    /**
     * Print all valid commands to the console
     */
    public String getCommandList()
    {
        StringBuilder sb = new StringBuilder();
        for(String command : validCommands) {
            sb.append(command).append(" ");
        }
        return sb.toString();
    }

    /**
     * Check whether a given String is a valid command word.
     * @return true if a given string is a valid command,
     * false if it isn't.
     */
    public boolean isCommand(String aString)
    {
        for(int i = 0; i < validCommands.length; i++) {
            if(validCommands[i].equals(aString))
                return true;
        }

        return false;
    }
}
