package ATM;

import java.time.*;
import java.time.format.*;
import java.util.*;
import java.lang.*;

/**
 *
 * This is a class to simulate an ATM.
 *
 * @author Evan R.
 * @version 1.6
 *
 *
 */


public class machine {

    private static int balance;


    public static void main(String[] args) {

        Scanner sc1 = new Scanner(System.in);

        System.out.println("Insert your ATM card please...");
        System.out.print("Enter your ID number...");
        while (!sc1.hasNextInt()) {
            System.out.println("That's not a number! Try again...");
            sc1.next();
        }
        int ID = sc1.nextInt();
        System.out.println();

        while (true) {
            System.out.println("Welcome to the ATM machine simulator");
            System.out.println("Enter 1 for a Withdrawal");
            System.out.println("Enter 2 for a Deposit");
            System.out.println("Enter 3 to check your balance");
            System.out.println("Enter 4 to end all transactions");
            System.out.println("...");
            while (!sc1.hasNextInt()) {
                System.out.println("That's not a number! Try again...");
                sc1.next();
            }
            int choice = sc1.nextInt();
            System.out.println();

            switch (choice) {
                case 1:
                    System.out.print("Enter the amount to be withdrawn in multiples of 20: ");
                    //checking to make sure it is even a number being entered.
                    while (!sc1.hasNextInt()) {
                        System.out.println("That's not a number! Try again...");
                        System.out.print("Enter the amount to be withdrawn in multiples of 20: ");
                        sc1.next();
                    }
                    int withdraw = sc1.nextInt();
                    //Make sure withdraw amount is a multiple of 20.
                    withdraw = checkWithdraw(withdraw);
                    //Check if you have enough money for the withdrawal, and then make the actual withdrawal.
                    withdraw(balance, withdraw);
                    break;
                case 2:
                    System.out.print("Enter the amount to be deposited: ");
                    //Check to make sure they are entering a number and accept the deposit amount from the user
                    while (!sc1.hasNextInt()) {
                        System.out.println("That's not a valid amount! Try again...");
                        System.out.print("Enter the amount to be deposited: ");
                        sc1.next();
                    }
                    int deposit = sc1.nextInt();
                    //Add the deposit amount to the total balance
                    deposit(balance, deposit);
                    break;
                case 3:
                    //Print the total balance
                    printBalance(balance);
                    System.out.println();
                    break;
                case 4:
                    //Exit from the ATM
                    System.out.println("Thank you for using the ATM! Remove your card & take your receipt.");
                    System.exit(0);
            }
        }
    }


    /**This method prints the balance, along with time current local date and time.
     *
     * @param balance
     */
    public static void printBalance(int balance) {
        machine.balance = balance;
        LocalDateTime dateObj = LocalDateTime.now();
        DateTimeFormatter formatDateObj = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mma");
        String formattedDate = dateObj.format(formatDateObj);

        System.out.println();
        System.out.println("The Current Balance: " + balance);
        System.out.println("Local Date/Time: " + formattedDate);
    }

    /**This function is to make sure the user is withdrawing a multiple of 20.
     *
     * @param withdrawAmount
     * @return withdrawAmount
     */
    public static int checkWithdraw(int withdrawAmount) {
        Scanner sc2 = new Scanner(System.in);
        while (withdrawAmount % 20 != 0) {
            System.out.println("Withdraws must be in multiples of 20...");
            System.out.print("Enter the amount to be withdrawn in multiples of 20: ");
            withdrawAmount = sc2.nextInt();
        }
        return withdrawAmount;
    }

    /**
     *
     * The function to Withdraw an amount and update the balance.
     *
      */
    public static int withdraw(int balance, int withdrawAmount) {
        System.out.println();
        System.out.println("Withdrawn Operation:");
        System.out.println("The withdrawal Amount is: " + withdrawAmount);
        if (balance >= withdrawAmount) {
            balance = balance - withdrawAmount;
            System.out.println("Please take your money.");
            printBalance(balance);
            System.out.println();
        } else {
            System.out.println("Sorry! Your funds are insufficient.");
            System.out.println();
        }
        return balance;
    }

    /**
     * The function to deposit an amount and update the balance.
     *
     *
      */
    public static int deposit(int balance, int depositAmount) {
        System.out.println();
        System.out.println("Deposit Operation:");
        System.out.println("The depositing amount is: " + depositAmount);
        machine.balance = balance + depositAmount;
        System.out.println("Your money has been successfully deposited");
        printBalance(machine.balance);
        System.out.println();
        return balance;
    }

    public static void setBalance(int balance) {
        machine.balance = balance;
    }
}


